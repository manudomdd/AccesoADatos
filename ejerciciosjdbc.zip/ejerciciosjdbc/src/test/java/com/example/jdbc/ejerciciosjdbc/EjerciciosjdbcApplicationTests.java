package com.example.jdbc.ejerciciosjdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjerciciosjdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
